using System;
using System.Collections.Generic;
using PrimitiveStart.Items;
using Terraria;
using Terraria.ModLoader;

namespace PrimitiveStart
{
	public class PrimitiveStartPlayer : ModPlayer
	{
		//Remove Vanilla's starting items.
		public override void ModifyStartingInventory(IReadOnlyDictionary<string, List<Item>> itemsByMod, bool mediumCoreDeath)
		{
			itemsByMod["Terraria"].RemoveAll((Item item) => item.type == 3506);
			itemsByMod["Terraria"].RemoveAll((Item item) => item.type == 3509);
			itemsByMod["Terraria"].RemoveAll((Item item) => item.type == 3507);
		}
		//Add Primitive Bag.
		public override IEnumerable<Item> AddStartingItems(bool mediumCoreDeath)
		{
			return new Item[]
			{
				new Item(ModContent.ItemType<CrudeBag>(), 1, 0)
			};
		}
	}
}