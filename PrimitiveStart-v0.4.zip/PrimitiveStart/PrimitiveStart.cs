using Terraria.ModLoader;

namespace PrimitiveStart
{
	public class PrimitiveStart : Mod
	{
	}
}