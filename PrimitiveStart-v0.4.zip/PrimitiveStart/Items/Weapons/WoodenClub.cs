using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace PrimitiveStart.Items.Weapons
{
	public class WoodenClub : ModItem
	{
		public override void SetStaticDefaults() 
		{
			DisplayName.SetDefault("Wooden Club");
		}

		public override void SetDefaults() 
		{
			Item.damage = 12;
			Item.width = 1;
			Item.height = 1;
			Item.scale = 1f;
			Item.useTime = 27;
			Item.useAnimation = 28;
			Item.useStyle = 1;
			Item.knockBack = 6;
			Item.value = 200;
			Item.rare = 0;
			Item.UseSound = SoundID.Item1;
			Item.autoReuse = false;
			Item.DamageType = DamageClass.Melee; //This is what allows Reforging to work on this item.
		}

		public override void AddRecipes()
		{
			CreateRecipe(1)
            .AddIngredient(ItemID.Wood,20)
            .Register();
		}
	}
}