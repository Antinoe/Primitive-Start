using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace PrimitiveStart.Items
{
	public class CrudeBag : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Crude Bag");
			Tooltip.SetDefault("{$CommonItemTooltip.RightClickToOpen}");
		}

		public override void SetDefaults()
		{
			Item.maxStack = 999;
			Item.consumable = true;
			Item.width = 24;
			Item.height = 24;
		}

		public override bool CanRightClick()
		{
			return true;
		}

		public override void RightClick(Player Player)
		{
			Player.QuickSpawnItem(ItemID.Wood, 30);
			Player.QuickSpawnItem(ItemID.StoneBlock, 25);
			Player.QuickSpawnItem(ItemID.Hay, 45);
			Player.QuickSpawnItem(ItemID.Acorn, 10);
			Player.QuickSpawnItem(ItemID.Cobweb, 25);
			Player.QuickSpawnItem(ItemID.Gel, 5);
		}
		
		public override void AddRecipes()
		{
			CreateRecipe(1)
			.AddIngredient(ItemID.Wood, 30)
			.AddIngredient(ItemID.StoneBlock, 25)
			.AddIngredient(ItemID.Hay, 45)
			.AddIngredient(ItemID.Acorn, 10)
			.AddIngredient(ItemID.Cobweb, 25)
			.AddIngredient(ItemID.Gel, 5)
			.AddTile(TileID.WorkBenches)
            .Register();
		}
	}
}