using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace PrimitiveStart.Items.Tools
{
	public class StoneAxe : ModItem
	{
		public override void SetStaticDefaults() 
		{
			DisplayName.SetDefault("Stone Axe");
			//Tooltip.SetDefault("Bare Hands: Break Blocks.");
		}

		public override void SetDefaults() 
		{
			Item.damage = 2;
			Item.width = 32;
			Item.height = 32;
			Item.useTime = 32;
			Item.useAnimation = 32;
			Item.useStyle = 1;
			Item.knockBack = 5;
			Item.value = 100;
			Item.rare = 1;
			Item.UseSound = SoundID.Item1;
			Item.autoReuse = true;
			Item.axe = 5;
		}

		public override void AddRecipes()
		{
			CreateRecipe(1)
            .AddIngredient(ItemID.Wood,3)
            .AddIngredient(3,9) //Stone
            .Register();
		}
	}
}