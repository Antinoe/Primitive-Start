using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace PrimitiveStart.Items.Tools
{
	public class StonePickaxe : ModItem
	{
		public override void SetStaticDefaults() 
		{
			DisplayName.SetDefault("Stone Pickaxe");
			//Tooltip.SetDefault("A rudimentary Pickaxe.");
		}

		public override void SetDefaults() 
		{
			Item.damage = 3;
			Item.width = 32;
			Item.height = 32;
			Item.useTime = 30;
			Item.useAnimation = 30;
			Item.useStyle = 1;
			Item.knockBack = 3;
			Item.value = 100;
			Item.rare = 1;
			Item.UseSound = SoundID.Item1;
			Item.autoReuse = true;
			Item.pick = 25;
		}

		public override void AddRecipes()
		{
			CreateRecipe(1)
            .AddIngredient(ItemID.Wood,3)
            .AddIngredient(3,12) //Stone
            .Register();
		}
	}
}