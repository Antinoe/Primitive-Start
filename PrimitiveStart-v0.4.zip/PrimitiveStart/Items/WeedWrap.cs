using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Microsoft.Xna.Framework;

namespace PrimitiveStart.Items
{
	public class WeedWrap : ModItem
	{
        public override void SetStaticDefaults()
        {
            Tooltip.SetDefault("A fine wrap of nutrients.\n" + "Helps with Fasting.");
        }

        public override void SetDefaults()
        {
            Item.width = 32;
            Item.height = 32;
			Item.scale = 1f;
			//Item.holdStyle = 1;
            Item.useStyle = 7;
            Item.useAnimation = 15;
            Item.useTime = 15;
            Item.useTurn = true;
            Item.UseSound = SoundID.Item2;
            Item.maxStack = 30;
            Item.consumable = true;
            Item.rare = 0;
            Item.value = 50;
			Item.buffType = BuffID.NeutralHunger;
            //Item.buffTime = 72000;
            Item.buffTime = 36000;
        }
		
		public override Vector2? HoldoutOffset()
		{
            return new Vector2(-2f, -2f);
        }
		
		public override void AddRecipes()
		{
			CreateRecipe(1)
            .AddIngredient(ItemID.Hay,12)
            .Register();
		}
    }
}